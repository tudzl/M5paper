#pragma once
// here you can put things like ssids and passwords
#define WIFI_SSID        "Staubli_SD"
//#define WIFI_PW          "your wifi password"
#define WIFI_PW          "smartdevice"
// For the Internet Connection
const char* ssid     = "Staubli_SD";
const char* password = "smartdevice";

const char* ssid1    = "changeme";
const char* password1= "changeme";

const char* ssid2    = "changeme";
const char* password2= "changeme";

const char* ssid3    = "changeme";
const char* password3= "changeme";
